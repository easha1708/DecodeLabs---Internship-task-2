/**
 * server.js
 *
 * DecodeLabs | Project 2: Backend API Development
 * "The Nervous System" — Engineering the Backend API & Architectural Integrity
 *
 * This is the API Gateway / Brain Stem: the single entry point that
 * receives every request, routes it to the correct controller, and
 * sends back a response — exactly like the IPO model from the deck:
 *
 *     INPUT (Client/Browser) -> PROCESS (Server/API) -> OUTPUT (JSON)
 */

const express = require("express");
const tasksRouter = require("./routes/tasks");
const { errorHandler, notFoundHandler } = require("./middleware/errorHandler");

const app = express();
const PORT = process.env.PORT || 3000;

// "The Neurotransmitter: JSON" — parse incoming JSON request bodies
app.use(express.json());

// Tiny request logger so every "signal" through the system is visible
app.use((req, res, next) => {
  console.log(`[Synapse API] ${req.method} ${req.originalUrl}`);
  next();
});

/**
 * GET /api/health
 * A simple "is the nervous system alive?" check.
 * Status: 200 OK
 */
app.get("/api/health", (req, res) => {
  res.status(200).json({
    status: "success",
    message: "Synapse API is online and responding.",
    timestamp: new Date().toISOString(),
  });
});

/**
 * GET /
 * Friendly root endpoint describing the API.
 * Status: 200 OK
 */
app.get("/", (req, res) => {
  res.status(200).json({
    status: "success",
    message: "Welcome to the Synapse API (DecodeLabs Project 2).",
    endpoints: {
      health: "GET /api/health",
      listTasks: "GET /api/tasks",
      getTask: "GET /api/tasks/:id",
      createTask: "POST /api/tasks",
      updateTask: "PUT /api/tasks/:id",
      deleteTask: "DELETE /api/tasks/:id",
    },
  });
});

// Mount the task resource routes
app.use("/api/tasks", tasksRouter);

// 404 — route doesn't exist (must come after all valid routes)
app.use(notFoundHandler);

// Global error handler — circuit breaker for unexpected failures
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Synapse API is running at http://localhost:${PORT}`);
  console.log(`Try: GET http://localhost:${PORT}/api/tasks`);
});
