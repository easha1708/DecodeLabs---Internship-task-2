/**
 * routes/tasks.js
 *
 * "The Language of Nerves: RESTful Naming"
 * Resources are nouns (/tasks), HTTP methods are verbs (GET, POST,
 * PUT, DELETE). Each handler follows the IPO model:
 *   INPUT   -> the incoming request (params, query, body)
 *   PROCESS -> validation + data store operations
 *   OUTPUT  -> a JSON response with the correct semantic status code
 */

const express = require("express");
const store = require("../data/store");
const {
  validateTaskCreate,
  validateTaskUpdate,
  validateIdParam,
} = require("../middleware/validate");

const router = express.Router();

/**
 * GET /api/tasks
 * Retrieve all tasks. Supports optional filtering via query params:
 *   ?completed=true|false
 *   ?priority=low|medium|high
 *
 * Status: 200 OK (always — an empty list is still a successful retrieval)
 */
router.get("/", (req, res) => {
  let tasks = store.getAll();
  const { completed, priority } = req.query;

  if (completed !== undefined) {
    const wantCompleted = completed === "true";
    tasks = tasks.filter((task) => task.completed === wantCompleted);
  }

  if (priority !== undefined) {
    tasks = tasks.filter((task) => task.priority === priority);
  }

  res.status(200).json({
    status: "success",
    count: tasks.length,
    data: tasks,
  });
});

/**
 * GET /api/tasks/:id
 * Retrieve a single task by ID.
 *
 * Status: 200 OK | 400 Bad Request | 404 Not Found
 */
router.get("/:id", validateIdParam, (req, res) => {
  const task = store.getById(req.taskId);

  if (!task) {
    return res.status(404).json({
      status: "error",
      message: `Task with id ${req.taskId} was not found.`,
    });
  }

  res.status(200).json({
    status: "success",
    data: task,
  });
});

/**
 * POST /api/tasks
 * Create a new task.
 *
 * Status: 201 Created | 400 Bad Request
 */
router.post("/", validateTaskCreate, (req, res) => {
  const { title, description, priority, completed } = req.body;
  const newTask = store.create({ title, description, priority, completed });

  // 201 Created + Location header pointing to the new resource
  res
    .status(201)
    .location(`/api/tasks/${newTask.id}`)
    .json({
      status: "success",
      message: "Task created successfully.",
      data: newTask,
    });
});

/**
 * PUT /api/tasks/:id
 * Update an existing task (partial updates allowed).
 *
 * Status: 200 OK | 400 Bad Request | 404 Not Found
 */
router.put("/:id", validateIdParam, validateTaskUpdate, (req, res) => {
  const updated = store.update(req.taskId, req.body);

  if (!updated) {
    return res.status(404).json({
      status: "error",
      message: `Task with id ${req.taskId} was not found.`,
    });
  }

  res.status(200).json({
    status: "success",
    message: "Task updated successfully.",
    data: updated,
  });
});

/**
 * DELETE /api/tasks/:id
 * Remove a task.
 *
 * Status: 204 No Content | 400 Bad Request | 404 Not Found
 */
router.delete("/:id", validateIdParam, (req, res) => {
  const existing = store.getById(req.taskId);

  if (!existing) {
    return res.status(404).json({
      status: "error",
      message: `Task with id ${req.taskId} was not found.`,
    });
  }

  store.remove(req.taskId);

  // 204 No Content: success, nothing to return in the body
  res.status(204).send();
});

module.exports = router;
