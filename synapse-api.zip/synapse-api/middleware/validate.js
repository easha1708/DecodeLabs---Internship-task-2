/**
 * middleware/validate.js
 *
 * "The Gatekeeper Rule: Never trust the client."
 *
 * This is the syntactic + semantic validation layer (the blood-brain
 * barrier from the slide deck). Nothing malformed gets through to the
 * data layer. If a request fails validation, we respond with a 400
 * Bad Request and a clear, actionable message — we never let bad data
 * silently pass or crash the server with a 500.
 */

const ALLOWED_PRIORITIES = ["low", "medium", "high"];

/**
 * Validates the body for creating a new task (POST /api/tasks).
 * Title is mandatory; everything else is optional with sane defaults.
 */
const validateTaskCreate = (req, res, next) => {
  const errors = [];
  const { title, description, priority, completed } = req.body || {};

  // Syntactic validation: is the format correct?
  if (title === undefined || title === null || title === "") {
    errors.push("'title' is required and cannot be empty.");
  } else if (typeof title !== "string") {
    errors.push("'title' must be a string.");
  } else if (title.trim().length < 3) {
    errors.push("'title' must be at least 3 characters long.");
  }

  if (description !== undefined && typeof description !== "string") {
    errors.push("'description' must be a string.");
  }

  // Semantic validation: is the logic valid?
  if (priority !== undefined && !ALLOWED_PRIORITIES.includes(priority)) {
    errors.push(`'priority' must be one of: ${ALLOWED_PRIORITIES.join(", ")}.`);
  }

  if (completed !== undefined && typeof completed !== "boolean") {
    errors.push("'completed' must be a boolean (true or false).");
  }

  if (errors.length > 0) {
    return res.status(400).json({
      status: "error",
      message: "Validation failed. The request body contains invalid data.",
      errors,
    });
  }

  next();
};

/**
 * Validates the body for updating a task (PUT /api/tasks/:id).
 * All fields are optional, but anything provided must be well-formed.
 */
const validateTaskUpdate = (req, res, next) => {
  const errors = [];
  const { title, description, priority, completed } = req.body || {};

  if (Object.keys(req.body || {}).length === 0) {
    errors.push("Request body cannot be empty. Provide at least one field to update.");
  }

  if (title !== undefined) {
    if (typeof title !== "string" || title.trim().length < 3) {
      errors.push("'title' must be a string of at least 3 characters.");
    }
  }

  if (description !== undefined && typeof description !== "string") {
    errors.push("'description' must be a string.");
  }

  if (priority !== undefined && !ALLOWED_PRIORITIES.includes(priority)) {
    errors.push(`'priority' must be one of: ${ALLOWED_PRIORITIES.join(", ")}.`);
  }

  if (completed !== undefined && typeof completed !== "boolean") {
    errors.push("'completed' must be a boolean (true or false).");
  }

  if (errors.length > 0) {
    return res.status(400).json({
      status: "error",
      message: "Validation failed. The request body contains invalid data.",
      errors,
    });
  }

  next();
};

/**
 * Validates the :id route parameter for single-resource routes.
 * Ensures the ID is a positive integer before we even hit the data layer.
 */
const validateIdParam = (req, res, next) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({
      status: "error",
      message: `'${req.params.id}' is not a valid task id. IDs must be positive integers.`,
    });
  }

  req.taskId = id;
  next();
};

module.exports = { validateTaskCreate, validateTaskUpdate, validateIdParam };
