/**
 * middleware/errorHandler.js
 *
 * "Circuit Breaker: Isolating failure."
 *
 * Any error thrown (or passed to next(err)) anywhere in the app lands
 * here. This guarantees that no matter what goes wrong internally,
 * the client always receives a clean, predictable JSON response with
 * a 500 status code instead of an HTML stack trace or a hung request.
 */
const errorHandler = (err, req, res, next) => {
  console.error("[Synapse API] Unexpected error:", err);

  res.status(500).json({
    status: "error",
    message: "Internal Server Error. The system encountered an unexpected fault.",
  });
};

/**
 * 404 handler for any route that doesn't match a defined endpoint.
 * "Resources are nouns. Methods are verbs." — if neither matches,
 * the resource simply does not exist.
 */
const notFoundHandler = (req, res) => {
  res.status(404).json({
    status: "error",
    message: `Route ${req.method} ${req.originalUrl} not found.`,
  });
};

module.exports = { errorHandler, notFoundHandler };
