/**
 * data/store.js
 *
 * In-memory "Data Persistence Layer" (the database stand-in).
 * In a real-world version, this would be swapped for MongoDB,
 * PostgreSQL, etc. — but the API contract above it would not change.
 * That separation is the whole point of a clean architecture.
 */

let tasks = [
  {
    id: 1,
    title: "Design API endpoints",
    description: "Plan out GET and POST routes for the task resource",
    priority: "high",
    completed: true,
    createdAt: "2026-06-10T09:00:00.000Z",
  },
  {
    id: 2,
    title: "Implement validation layer",
    description: "Reject malformed requests before they reach the data layer",
    priority: "high",
    completed: false,
    createdAt: "2026-06-11T09:00:00.000Z",
  },
  {
    id: 3,
    title: "Write documentation",
    description: "If it isn't documented, it doesn't exist",
    priority: "medium",
    completed: false,
    createdAt: "2026-06-12T09:00:00.000Z",
  },
];

let nextId = 4;

const getAll = () => tasks;

const getById = (id) => tasks.find((task) => task.id === id);

const create = ({ title, description, priority, completed }) => {
  const newTask = {
    id: nextId++,
    title,
    description: description || "",
    priority: priority || "medium",
    completed: completed || false,
    createdAt: new Date().toISOString(),
  };
  tasks.push(newTask);
  return newTask;
};

const update = (id, updates) => {
  const task = getById(id);
  if (!task) return null;

  if (updates.title !== undefined) task.title = updates.title;
  if (updates.description !== undefined) task.description = updates.description;
  if (updates.priority !== undefined) task.priority = updates.priority;
  if (updates.completed !== undefined) task.completed = updates.completed;

  return task;
};

const remove = (id) => {
  const index = tasks.findIndex((task) => task.id === id);
  if (index === -1) return false;
  tasks.splice(index, 1);
  return true;
};

module.exports = { getAll, getById, create, update, remove };
